# auipc_test.S 程序级测试

- 结果：PASS
- 指令数：8
- 测试期间 RTL 未变：True

覆盖 AUIPC 使用当前 PC、U-type 低12位清零、位31边界、加法回绕和 x0 保护。
