# 一键回归测试

总结果：**PASS**

| 项目 | 结果 |
|---|---|
| units | PASS |
| soc | PASS |
| wait2 | PASS |
| wait5 | PASS |
| mem_test | PASS |
| branch_test | PASS |
| jal_test | PASS |
| jalr_test | PASS |
| lui_test | PASS |
| RTL 未修改 | PASS |

## 子测试结果

- `core` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/20260926-221240-057294`
- `mem` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/mem-test-20260926-221241-375210`
- `branch` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/branch-test-20260926-221241-446446`
- `jal` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/jal-test-20260926-221241-533494`
- `jalr` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/jalr-test-20260926-221241-612401`
- `lui` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/lui-test-20260926-221241-688160`
