# LUI/AUIPC 流水线验证

结果：**PASS**

覆盖：零/正/高位为 1 的 U 型立即数；LUI/AUIPC 后紧随 ADDI；x0；立即数字段不产生假 RAW；
U 型结果用于 Store 数据、Load/Store 地址、JALR 和 BEQ；Load/Store 等待时的 AUIPC；
跳转后 AUIPC 使用自身 PC；错误路径上的 LUI/AUIPC 被清除；高地址 PC 加法的 32 位回绕。

逐条核对退休 PC、指令、写使能和写回值，并核对全部寄存器。实际数据 RAM 分别使用直接连接、接收前等待 2 拍和响应延迟 5 拍。

## direct_ram

```text
VCD info: dumpfile direct_ram.vcd opened for output.
PASS pipeline_upper instructions=59 upper=31 cycles=92 raw_bubbles=23 memory_holds=5
/Users/wuleyan/Desktop/FPGA大赛/tests/tb_pipeline_upper.sv:183: $finish called at 946000 (1ps)
```

## delayed_ram

```text
VCD info: dumpfile delayed_ram.vcd opened for output.
PASS pipeline_upper instructions=59 upper=31 cycles=132 raw_bubbles=23 memory_holds=45
/Users/wuleyan/Desktop/FPGA大赛/tests/tb_pipeline_upper.sv:183: $finish called at 1346000 (1ps)
```
