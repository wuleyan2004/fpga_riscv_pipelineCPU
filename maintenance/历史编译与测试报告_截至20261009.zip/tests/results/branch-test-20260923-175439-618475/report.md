# branch_test.S 程序级测试

- 结果：PASS
- 指令数：34
- 测试期间 RTL 未变：True

覆盖 BEQ/BNE/BLT/BGE/BLTU/BGEU 的跳转成立和不成立，有符号/无符号区别，以及负偏移的向后循环。
