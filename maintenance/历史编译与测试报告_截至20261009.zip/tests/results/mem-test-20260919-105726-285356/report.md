# mem_test.S 程序级测试

- 结果：PASS
- 工具链：GNU assembler (GNU Binutils) 2.47.20260726
- 指令数：36
- 测试期间RTL未变：True

覆盖 SW/LW/SB/LB/LBU/SH/LH/LHU、正负偏移、小端字节通道、符号/零扩展、x0保护、访存等待和Store不重复。
