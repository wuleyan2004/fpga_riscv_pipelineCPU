# 测试结果

RTL SHA-256 前后相同：True

| 测试 | 结果 |
|---|---|
| units | PASS |
| soc | PASS |
| wait2 | PASS |
| wait5 | PASS |

范围：ALU、立即数、完整OP/OP-IMM译码、寄存器堆、RAM、SB/SH/SW、LB/LBU/LH/LHU/LW、实际 SoC 程序，以及延长请求等待2/5周期。
本套不测试跳转执行；跳转由专项套件验证。错位异常和地址越界保护不计为通过；错位 Load 当前完成内存握手但不写 rd，错位 Store 使用零写掩码。
program.hex由随附的小型测试编码器生成，并非GCC汇编产物。
详细结果见 *.run.log；波形见 *.vcd；原始RTL哈希见 manifest.json。
