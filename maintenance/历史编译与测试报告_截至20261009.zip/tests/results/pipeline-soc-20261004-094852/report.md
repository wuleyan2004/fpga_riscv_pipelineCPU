# 流水线核接入 SoC 验证

结果：**PASS**，日期：2026-10-04。

`soc_top.u_cpu_core` 由 `cpu_core` 改为 `cpu_core_pipeline`，沿用 ROM 和 RAM/GPIO/UART 的接口。
未映射地址判断包含 UART 排除条件。`board_top` 自动使用流水线核。

GPIO/UART 测试源列表改为递归读取 `源代码/`；结束条件改为最后一条指令完成 WB。

| 测试 | 结果 | 证据 |
|---|---|---|
| GPIO、RAM、未映射访问 | PASS | 42 条指令，81 拍，GPIO 21 次请求，输入读 3 次 |
| UART TX 引脚与忙时等待 | PASS | 3 帧，启动 3 次，忙时等待 8670 拍，总计 13045 拍 |
| board_top 内置演示 | PASS | GPIO=01，UART 连续输出两次 `4f 4b 0a`，共 6 帧；复位和按钮映射通过 |

GPIO/UART 同时检查请求在等待期间稳定、地址分发、Store 次数、最终寄存器和复位。
两套脚本的 RTL 前后哈希一致。

- [GPIO 日志](/Users/wuleyan/Desktop/FPGA大赛/tests/results/gpio-test-20261004-094852-104114/run.log)
- [UART 日志](/Users/wuleyan/Desktop/FPGA大赛/tests/results/uart-test-20261004-094852-104055/run.log)
- [重跑命令与测试说明](/Users/wuleyan/Desktop/FPGA大赛/tests/README.md)

板级演示执行命令与输出：

```sh
iverilog -g2012 -s tb_board_demo -o /tmp/fpga-pipeline-board-demo.vvp 源代码/*.v 源代码/cpu/*.v tests/tb_board_demo.sv
vvp /tmp/fpga-pipeline-board-demo.vvp
```

```text
PASS board_demo.S GPIO=01 UART=4f 4b 0a repeated frames=6
tests/tb_board_demo.sv:93: $finish called at 516366277 (1ps)
```

调试含义：`debug_pc` / `debug_instruction` 是 IF 级取指状态，不能用作访存指令 PC 或程序退休标志。

范围：RTL SoC 与 board_top 仿真，未进行 FPGA 综合、时序收敛或实物上板。早期全套回归脚本尚未全部迁移。
