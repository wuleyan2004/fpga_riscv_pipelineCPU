# 数据前递修改与验证

日期：2026-10-04；结果：**PASS**。

## 实现

`cpu_core_pipeline` 增加 WB → EX 前递，选择最终写回数据供 ALU、分支比较、JALR 地址和 Store 数据使用。
条件包含有效指令、寄存器写使能、目标非 x0；Load 必须等响应返回且访问对齐。
能够前递时取消 RAW 暂停，访存等待仍优先保持整条流水线。

## 验证与周期对比

| 测试 | 结果 | 证据 |
|---|---|---|
| 连续算术依赖 | PASS | x1=5、x2=12、x3=24；5 条指令 7 拍，无 RAW 气泡，双操作数前递 |
| 控制流前递，直接 RAM | PASS | 88 拍；全部六类分支；Load → 分支 2 次、Load → JALR 1 次；Store 5 次，无错误路径写入 |
| 控制流前递，接收等待 2 拍/响应延迟 5 拍 | PASS | 160 拍；Load 等待 36 拍时未提前写回或前递；结果与直接 RAM 相同 |
| 97 条访存程序，5 种等待配置 | 全部 PASS | 每种配置 29 次 EX 前递、24 次 Load 前递；请求稳定、全寄存器、全 RAM、写入次数、错位行为正确 |
| 59 条 U 型程序，2 种等待配置 | 全部 PASS | 22 次 U 型结果前递；无假源依赖；跳转冲刷及 PC 回绕正确 |
| 实际 SoC GPIO 程序 | PASS | 71 拍，GPIO 21 次请求，输入读 3 次；RAM 与未映射访问正常 |
| 实际 SoC UART 程序 | PASS | 3 帧、启动 3 次；忙时等待 8672 拍，请求稳定，无重复发送 |
| board_top 演示 | PASS | GPIO=01，UART 两次 `OK\n` 共 6 帧；按钮与复位通过 |

相同程序和 RAM 配置下的周期变化：

| 程序/配置 | 前递前 | 前递后 |
|---|---:|---:|
| 访存 direct_ram | 191 | 162 |
| 访存 buffered | 254 | 225 |
| 访存 accept_wait2 | 380 | 351 |
| 访存 response_wait5 | 569 | 540 |
| 访存 variable_wait | 851 | 822 |
| U 型 direct_ram | 92 | 69 |
| U 型 delayed_ram | 132 | 109 |

访存程序的 29 个 RAW 气泡、U 型程序的 23 个 RAW 气泡均消除；外部存储器要求的等待周期保持。
这些是指定测试程序的周期对比，不代表任意程序的固定加速比例。

## 日志与重跑

- [前递专项报告、日志和波形](/Users/wuleyan/Desktop/FPGA大赛/tests/results/pipeline-forward-20261004-102335-027259/report.md)
- [访存报告、日志和波形](/Users/wuleyan/Desktop/FPGA大赛/tests/results/pipeline-mem-20261004-102014-964817/report.md)
- [U 型报告、日志和波形](/Users/wuleyan/Desktop/FPGA大赛/tests/results/pipeline-upper-20261004-102014-964325/report.md)
- [GPIO 运行日志](/Users/wuleyan/Desktop/FPGA大赛/tests/results/gpio-test-20261004-102335-028400/run.log)
- [UART 运行日志](/Users/wuleyan/Desktop/FPGA大赛/tests/results/uart-test-20261004-102335-028248/run.log)
- [重跑命令](/Users/wuleyan/Desktop/FPGA大赛/tests/README.md)

板级演示输出：

```text
PASS board_demo.S GPIO=01 UART=4f 4b 0a repeated frames=6
tests/tb_board_demo.sv:93: $finish called at 516292201 (1ps)
```

范围：RTL 仿真。前递增加了 WB 数据到 EX 计算的组合路径，本轮未验证 FPGA 综合和时序收敛。
