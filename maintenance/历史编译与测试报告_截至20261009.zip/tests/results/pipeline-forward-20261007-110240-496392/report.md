# WB → EX 数据前递验证

结果：**PASS**

覆盖连续算术依赖、两个源同时依赖、同一寄存器连续写入、x0、非法指令；
全部六类分支的源操作数前递和 taken/not-taken，Load → 分支、Load → JALR；
错误路径 Store 清除、Store 实际写入次数、Load 数据返回前禁止前递、等待时请求与 PC 稳定。

实际 sync_data_ram 使用直接连接和接收前等待 2 拍/响应延迟 5 拍两种配置。

## arithmetic

```text
vvp /Users/wuleyan/Desktop/FPGA大赛/tests/results/pipeline-forward-20261007-110240-496392/arithmetic.vvp +WAVE=arithmetic.vcd
PASS pipeline RAW forwarding stalls=0 x2=12 x3=24
/Users/wuleyan/Desktop/FPGA大赛/tests/tb_pipeline_raw_stall.sv:57: $finish called at 86000 (1ps)
```

## direct_ram

```text
vvp /Users/wuleyan/Desktop/FPGA大赛/tests/results/pipeline-forward-20261007-110240-496392/direct_ram.vvp +WAVE=direct_ram.vcd
VCD info: dumpfile direct_ram.vcd opened for output.
PASS pipeline_forward cycles=88 raw_bubbles=0 branch_rs1=13 branch_rs2=7 load_branches=2 load_jalr=1 both_ports=2 load_waits=4 stores=5
/Users/wuleyan/Desktop/FPGA大赛/tests/tb_pipeline_forward.sv:103: $finish called at 906000 (1ps)
```

## delayed_ram

```text
vvp /Users/wuleyan/Desktop/FPGA大赛/tests/results/pipeline-forward-20261007-110240-496392/delayed_ram.vvp +WAVE=delayed_ram.vcd
VCD info: dumpfile delayed_ram.vcd opened for output.
PASS pipeline_forward cycles=160 raw_bubbles=0 branch_rs1=13 branch_rs2=7 load_branches=2 load_jalr=1 both_ports=2 load_waits=36 stores=5
/Users/wuleyan/Desktop/FPGA大赛/tests/tb_pipeline_forward.sv:103: $finish called at 1626000 (1ps)
```
