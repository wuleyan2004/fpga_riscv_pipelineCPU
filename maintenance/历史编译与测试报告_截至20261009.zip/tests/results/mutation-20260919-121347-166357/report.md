# 故障注入实验：LB 符号扩展

- 结果：**PASS**
- 原始回归通过：True
- 改错后被测试抓住：True
- 真实 RTL 未改动：True

实验只修改结果目录中的 `mutated_rtl/cpu_core.v`：将 LB 的符号扩展故意改为零扩展。预期是变异版仿真失败，因此“被抓住”才表示本实验 PASS。
