# 一键回归测试

总结果：**PASS**

| 项目 | 结果 |
|---|---|
| units | PASS |
| soc | PASS |
| wait2 | PASS |
| wait5 | PASS |
| mem_test | PASS |
| RTL 未修改 | PASS |

## 子测试结果

- `core` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/20260919-121446-305818`
- `mem` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/mem-test-20260919-121447-684170`
