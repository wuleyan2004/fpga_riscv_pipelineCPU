# 一键回归测试

总结果：**PASS**

| 项目 | 结果 |
|---|---|
| day5_soc | PASS |
| day5_wait2 | PASS |
| day5_wait5 | PASS |
| units | PASS |
| soc | PASS |
| wait2 | PASS |
| wait5 | PASS |
| mem_test | PASS |
| branch_test | PASS |
| jal_test | PASS |
| jalr_test | PASS |
| lui_test | PASS |
| auipc_test | PASS |
| RTL 未修改 | PASS |

## 子测试结果

- `day5` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/day5-20260927-150524-559768`
- `core` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/20260927-150524-797075`
- `mem` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/mem-test-20260927-150527-144479`
- `branch` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/branch-test-20260927-150527-249681`
- `jal` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/jal-test-20260927-150527-369236`
- `jalr` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/jalr-test-20260927-150527-486325`
- `lui` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/lui-test-20260927-150527-593504`
- `auipc` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/auipc-test-20260927-150527-703566`
