# jalr_test.S 程序级测试

- 结果：PASS
- 指令数：22
- 测试期间 RTL 未变：True

覆盖 JAL/JALR 函数调用和返回、rd=PC+4、目标最低位清零、I-type 正/负偏移和跳过指令。
