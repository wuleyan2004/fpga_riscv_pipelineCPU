# mem_test.S 程序级测试

- 结果：PASS
- 工具链：GNU assembler (GNU Binutils) 2.47.20260726
- 指令数：36
- 测试期间RTL未变：True

覆盖 SW/LW/SB/LB/LBU/SH/LH/LHU、正负偏移、小端字节通道、符号/零扩展、x0保护、访存等待和Store不重复。

- 核心寄存器签名：`x10=ffffffff, x11=44332211, x14=ffffff80, x15=00000080, x16=f8000123, x19=fffff800, x20=0000f800, x22=44332211, x23=0000007b`
- RAM签名：`RAM[16]=ffffffff, RAM[17]=44338011, RAM[18]=f8000123, RAM[19]=44332211`
