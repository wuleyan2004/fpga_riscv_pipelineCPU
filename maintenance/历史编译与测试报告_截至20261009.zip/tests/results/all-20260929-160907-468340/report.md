# 一键回归测试

总结果：**PASS**

| 项目 | 结果 |
|---|---|
| uart_test | PASS |
| gpio_test | PASS |
| day5_soc | PASS |
| day5_wait2 | PASS |
| day5_wait5 | PASS |
| units | PASS |
| soc | PASS |
| wait2 | PASS |
| wait5 | PASS |
| mem_test | PASS |
| branch_test | PASS |
| jal_test | PASS |
| jalr_test | PASS |
| lui_test | PASS |
| auipc_test | PASS |
| RTL 未修改 | PASS |

## 子测试结果

- `uart` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/uart-test-20260929-160907-496637`
- `gpio` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/gpio-test-20260929-160907-722971`
- `day5` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/day5-20260929-160907-782180`
- `core` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/20260929-160907-909584`
- `mem` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/mem-test-20260929-160909-093411`
- `branch` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/branch-test-20260929-160909-172031`
- `jal` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/jal-test-20260929-160909-233154`
- `jalr` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/jalr-test-20260929-160909-292382`
- `lui` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/lui-test-20260929-160909-352084`
- `auipc` 详细结果：`/Users/wuleyan/Desktop/FPGA大赛/tests/results/auipc-test-20260929-160909-409955`
