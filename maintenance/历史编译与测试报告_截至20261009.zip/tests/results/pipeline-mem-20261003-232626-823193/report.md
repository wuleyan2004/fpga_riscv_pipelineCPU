# 流水线访存验证

总结果：**PASS**

程序 97 条；访存 63 次；Store 17 次（有效写入 12 次）；错位访问 12 次。

预期由按字节内存软件模型生成；仿真连接实际 sync_data_ram。

| 场景 | RAM 接收前额外等待 | 响应延迟 | 结果 |
|---|---:|---:|---|
| direct_ram | 0 | 0 | PASS |
| buffered | 0 | 0 | PASS |
| accept_wait2 | 2 | 0 | PASS |
| response_wait5 | 0 | 5 | PASS |
| variable_wait | 2 | 5 | PASS |

variable_wait 在基准延迟上分别增加 0—2、0—3 拍。

检查：全部退休指令/写回顺序、全寄存器值、全 1 KiB RAM、请求稳定、等待时整条流水线保持、实际 RAM 接收/写次数、错位调试脉冲。

覆盖：LB/LBU 四字节位置、LH/LHU 两半字、LW，SB 四位置、SH 两位置、SW；负偏移与首尾边界；Load→算术/Store 数据/Store 地址/Load 地址；x0；错位 Load 保持 rd、错位 Store 零掩码。

本验证范围为流水线核与数据 RAM，不包含 MMIO、整机接线、FPGA 综合或实物验证。

RTL 在测试期间未修改；哈希见 manifest.json。
