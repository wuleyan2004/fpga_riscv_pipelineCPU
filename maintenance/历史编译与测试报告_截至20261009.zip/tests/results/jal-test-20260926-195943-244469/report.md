# jal_test.S 程序级测试

- 结果：PASS
- 指令数：13
- 测试期间 RTL 未变：True

覆盖 JAL 向前正偏移、向后负偏移、rd=PC+4、jal x0 纯跳转、跳过指令和循环退出。
