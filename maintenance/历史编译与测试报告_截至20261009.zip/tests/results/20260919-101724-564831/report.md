# 测试结果

RTL SHA-256 前后相同：True

| 测试 | 结果 |
|---|---|
| units | PASS |
| soc | PASS |
| wait2 | PASS |
| wait5 | PASS |

范围：ALU、立即数、Decoder、寄存器堆、RAM、SB/SH/SW 字节通道、实际 SoC 程序，以及延长请求等待2/5周期。
未实现的字节/半字 Load、分支跳转执行、错位标志/异常及地址越界保护不计为通过；错位 SH/SW 当前仅验证零写掩码。
program.hex由随附的小型测试编码器生成，并非GCC汇编产物。
详细结果见 *.run.log；波形见 *.vcd；原始RTL哈希见 manifest.json。
